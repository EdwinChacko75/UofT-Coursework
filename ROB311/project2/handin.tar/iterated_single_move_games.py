from abc import ABC, abstractmethod
import numpy as np


class SingleMoveGamePlayer(ABC):
    """
    Abstract base class for a symmetric, zero-sum single move game player.
    """
    def __init__(self, game_matrix: np.ndarray):
        self.game_matrix = game_matrix
        self.n_moves = game_matrix.shape[0]
        super().__init__()

    @abstractmethod
    def make_move(self) -> int:
        pass


class IteratedGamePlayer(SingleMoveGamePlayer):
    """
    Abstract base class for a player of an iterated symmetric, zero-sum single move game.
    """
    def __init__(self, game_matrix: np.ndarray):
        super(IteratedGamePlayer, self).__init__(game_matrix)

    @abstractmethod
    def make_move(self) -> int:
        pass

    @abstractmethod
    def update_results(self, my_move, other_move):
        """
        This method is called after each round is played
        :param my_move: the move this agent played in the round that just finished
        :param other_move:
        :return:
        """
        pass

    @abstractmethod
    def reset(self):
        """
        This method is called in between opponents (forget memory, etc.)
        :return:
        """
        pass


class UniformPlayer(IteratedGamePlayer):
    def __init__(self, game_matrix: np.ndarray):
        super(UniformPlayer, self).__init__(game_matrix)

    def make_move(self) -> int:
        """

        :return:
        """
        return np.random.randint(0, self.n_moves)

    def update_results(self, my_move, other_move):
        """
        The UniformPlayer player does not use prior rounds' results during iterated games.
        :param my_move:
        :param other_move:
        :return:
        """
        pass

    def reset(self):
        """
        This method is called in between opponents (forget memory, etc.)
        :return:
        """
        pass


class FirstMovePlayer(IteratedGamePlayer):
    def __init__(self, game_matrix: np.ndarray):
        super(FirstMovePlayer, self).__init__(game_matrix)

    def make_move(self) -> int:
        """
        Always chooses the first move
        :return:
        """
        return 0

    def update_results(self, my_move, other_move):
        """
        The FirstMovePlayer player does not use prior rounds' results during iterated games.
        :param my_move:
        :param other_move:
        :return:
        """
        pass

    def reset(self):
        """
        This method is called in between opponents (forget memory, etc.)
        :return:
        """
        pass

class CopycatPlayer(IteratedGamePlayer):
    def __init__(self, game_matrix: np.ndarray):
        super(CopycatPlayer, self).__init__(game_matrix)
        self.last_move = np.random.randint(self.n_moves)

    def make_move(self) -> int:
        """
        Always copies the last move played
        :return:
        """
        return self.last_move

    def update_results(self, my_move, other_move):
        """
        The CopyCat player simply remembers the opponent's last move.
        :param my_move:
        :param other_move:
        :return:
        """
        self.last_move = other_move

    def reset(self):
        """
        This method is called in between opponents (forget memory, etc.)
        :return:
        """
        self.last_move = np.random.randint(self.n_moves)


def play_game(player1, player2, game_matrix: np.ndarray, N: int = 1000) -> (int, int):
    """

    :param player1: instance of an IteratedGamePlayer subclass for player 1
    :param player2: instance of an IteratedGamePlayer subclass for player 2
    :param game_matrix: square payoff matrix
    :param N: number of rounds of the game to be played
    :return: tuple containing player1's score and player2's score
    """
    N = 10000
    p1_score = 0.0
    p2_score = 0.0
    n_moves = game_matrix.shape[0]
    legal_moves = set(range(n_moves))
    for idx in range(N):
        move1 = player1.make_move()
        move2 = player2.make_move()
        if move1 not in legal_moves:
            print("WARNING: Player1 made an illegal move: {:}".format(move1))
            if move2 not in legal_moves:
                print("WARNING: Player2 made an illegal move: {:}".format(move2))
            else:
                p2_score += np.max(game_matrix)
                p1_score -= np.max(game_matrix)
            continue
        elif move2 not in legal_moves:
            print("WARNING: Player2 made an illegal move: {:}".format(move2))
            p1_score += np.max(game_matrix)
            p2_score -= np.max(game_matrix)
            continue
        player1.update_results(move1, move2)
        player2.update_results(move2, move1)

        p1_score += game_matrix[move1, move2]
        p2_score += game_matrix[move2, move1]

    return p1_score, p2_score

class FirstMoveDestroyer(IteratedGamePlayer):
    def __init__(self, game_matrix: np.ndarray):
        super(FirstMoveDestroyer, self).__init__(game_matrix)
    def make_move(self) -> int:
        return 1
    def update_results(self, my_move, other_move):
        pass
    def reset(self):
        pass

class CopycatDestroyer(IteratedGamePlayer):
    def __init__(self, game_matrix: np.ndarray, prev_move):
        super(CopycatDestroyer, self).__init__(game_matrix)
        self.prev_move = prev_move
    def make_move(self) -> int:
        return int(np.argmin(self.game_matrix[self.prev_move]))
    def update_results(self, my_move, other_move):
        self.prev_move =  my_move
        
    def reset(self):
        pass

class StudentAgent(IteratedGamePlayer):
    """
    This class is a wrapper and it plays one of three classes. If we find the pattern
    is copycating or spamming, we instantiate the respective model to take over. It 
    is then disposed of on reset. This nearly garuntees those cases are passed, allowing 
    the QLearner to be better fine tuned for playing other agents. The Q-Learning algorithm
    here is Double Q-Learning as it helps reduce overstimation bias, increase stability, 
    and promotes exploration. It has been found to be better than single q learning. I 
    use epsilon-greedy to promote exploration. I use many hyperparameters, notably, we 
    have a dynamic epsilon-greedy cut-off, which allows more exploration early on, and 
    then later, less aggressive exploration, as we already have a sense of what to do.
    It is an inverse relationship. See QLearner.game_ctr. At episode 500, both the learning 
    rate and the e-g cut-off are reduced further, but this has shown little impact. 
    We use a self.history_length to define how many previous moves are used to define 
    the current state. Values were test from 1 to 12, and 2-3 has been a clear winner.
    High values, above 5, lose meaning as states are not seen enough to matter. A sort
    of hapax legomenon. 3 is chosen, though 2 is a close second.
    """
    def __init__(self, game_matrix: np.ndarray):
        super(StudentAgent, self).__init__(game_matrix)
        self.agent = QLearner(game_matrix)
        self.main = self.agent
        self.my_moves = np.empty((1,0))
        self.opp_moves = np.empty((1,0))
        self.results = np.empty((1,0))

    def make_move(self):
        return self.agent.make_move()
    
    def update_results(self, my_move, other_move):
        # Update logs
        self.my_moves = np.append(self.my_moves, my_move)
        self.opp_moves = np.append(self.opp_moves, other_move)
        self.results = np.append(self.results, self.agent.game_matrix[my_move, other_move])

        # On the 8th move, see if we have spotted a pattern to exploit. 
        # 8 Chosen because (1/3)^7 -> very low. Could have picked 10.
        if self.opp_moves.shape == (8,):
            if np.sum(self.opp_moves) == 0:
                self.agent = FirstMoveDestroyer(self.game_matrix)
            elif (self.my_moves[:-1] == self.opp_moves[1:]).all():
                self.agent = CopycatDestroyer(self.game_matrix, my_move)
                self.agent.prev_move = my_move
        
        return self.agent.update_results(my_move, other_move)
    
    def reset(self):
        self.agent = self.main 
        self.my_moves = np.empty((1,0))
        self.opp_moves = np.empty((1,0))
        self.results = np.empty((1,0))

        return self.agent.reset()
    
class QLearner(IteratedGamePlayer):
    """
    Double Q Learner.  
    """
    def __init__(self, game_matrix: np.ndarray, history_length: int = 3):
        """
        Initialize your game playing agent. here
        :param game_matrix: square payoff matrix for the game being played.
        """
        super(QLearner, self).__init__(game_matrix)
        self.history_length = history_length

        self.current_state = tuple(0 for _ in range(self.history_length))
        self.all_states = self.generate_states(history_length)

        self.Qb_threshold = 0.5 # reduces to regular q learning if 0

        self.Qa = {}
        self.Qb = {}
        for state in self.all_states:
            self.Qa[state] = np.zeros(self.n_moves)
            self.Qb[state] = np.zeros(self.n_moves)
        
        # Learning parameters.
        self.alpha = 0.2    # learning rate
        self.gamma = 0.9    # discount factor
        self.epsilon = 8    # exploration rate (decays with time)
        self.game_ctr = 0
        self.epsilon_clipping = 0.01

    def generate_states(self, history_length):
        """ Manually generates all possible state combinations. """
        states = []
        def generate(current):
            if len(current) == history_length:
                states.append(tuple(current))
                return
            for move in range(self.n_moves):
                generate(current + [move])
        generate([])
        return states

    def make_move(self) -> int:
        """
        Play your move based on previous moves or whatever reasoning you want.
        :return: an int in (0, ..., n_moves-1) representing your move
        """
        # YOUR CODE GOES HERE
        self.game_ctr += 1

        # does nothing
        if self.game_ctr == 500:
            self.alpha = 0.05
            self.epsilon_clipping = 0.01
        
        # Threshold the eplilon-greedy to introduce randomness
        threshold = max(self.epsilon_clipping, self.epsilon / self.game_ctr)

        # Epsilon greedy
        if np.random.rand() < threshold:
            action = np.random.randint(0, self.n_moves)
        else:
            combined_Q = self.Qa[self.current_state] + self.Qb[self.current_state]
            action = int(np.argmax(combined_Q))
        return action

    def update_results(self, my_move, other_move):
        """
        Update your agent based on the round that was just played.
        :param my_move:
        :param other_move:
        :return: nothing
        """
        # YOUR CODE GOES HERE
        reward = self.game_matrix[my_move, other_move]
        next_state = tuple(self.current_state[1:] + (other_move,))

        # Double Q Learning
        if np.random.rand() < self.Qb_threshold:
            best_next_action = int(np.argmax(self.Qa[next_state]))
            td_target = reward + self.gamma * self.Qb[next_state][best_next_action]
            td_error = td_target - self.Qa[self.current_state][my_move]
            self.Qa[self.current_state][my_move] += self.alpha * td_error
        else:
            best_next_action = int(np.argmax(self.Qb[next_state]))
            td_target = reward + self.gamma * self.Qa[next_state][best_next_action]
            td_error = td_target - self.Qb[self.current_state][my_move]
            self.Qb[self.current_state][my_move] += self.alpha * td_error

        self.current_state = next_state

    def reset(self):
        """
        This method is called in between opponents (forget memory, etc.).
        :return: nothing
        """
        # YOUR CODE GOES HERE
        self.current_state = tuple(0 for _ in range(self.history_length))
        for state in self.all_states:
            self.Qa[state] = np.zeros(self.n_moves)
            self.Qb[state] = np.zeros(self.n_moves)
        self.game_ctr = 0



if __name__ == '__main__':
    """
    Simple test on standard rock-paper-scissors
    The game matrix's row (first index) is indexed by player 1 (P1)'s move (i.e., your move)
    The game matrix's column (second index) is indexed by player 2 (P2)'s move (i.e., the opponent's move)
    Thus, for example, game_matrix[0, 1] represents the score for P1 when P1 plays rock and P2 plays paper: -1.0 
    because rock loses to paper.
    """
    game_matrix = np.array([[0.0, -1.0, 1.0],
                            [1.0, 0.0, -1.0],
                            [-1.0, 1.0, 0.0]])
    student_player = StudentAgent(game_matrix)
    student_player.reset()

    print("Student Versus Uniform")
    uniform_player = UniformPlayer(game_matrix)
    student_score, uniform_score = play_game(student_player, uniform_player, game_matrix)

    print("Student player's score: {:}".format(student_score))
    print("Uniform player's score: {:}\n".format(uniform_score))
    student_player.reset()

    print("Student Versus First Move")

    first_move_player = FirstMovePlayer(game_matrix)
    student_score, first_move_score = play_game(student_player, first_move_player, game_matrix)

    print("Student player's score: {:}".format(student_score))
    print("First-move player's score: {:}\n".format(first_move_score))
    student_player.reset()

    print("Student Versus Copycat")

    copycat_player = CopycatPlayer(game_matrix)
    student_score, copycat_score = play_game(student_player, copycat_player, game_matrix)

    print("Student player's score: {:}".format(student_score))
    print("First-move player's score: {:}\n".format(copycat_score))
    
    student_player.reset()


    print("Student Versus Agent")

    # Now try your agent
    agent = StudentAgent(game_matrix)
    agent.agent.alpha = 0.2   # learning rate
    agent.agent.gamma = 0.9   # discount factor
    agent.agent.epsilon = 8   # exploration rate
    agent.agent.game_ctr = 0
    agent.agent.epsilon_clipping = 0.01

    agent.agent = QLearner(agent.game_matrix)
    agent.main = agent.agent
    student_score, first_move_score = play_game(student_player, agent, game_matrix)

    print("Your player's score: {:}".format(student_score))
    print("Agent player's score: {:}\n".format(first_move_score))
