import numpy as np
### WARNING: DO NOT CHANGE THE NAME OF THIS FILE, ITS FUNCTION SIGNATURE OR IMPORT STATEMENTS


def min_conflicts_n_queens(initialization: list) -> (list, int):
    """
    Solve the N-queens problem with no conflicts (i.e. each row, column, and diagonal contains at most 1 queen).
    Given an initialization for the N-queens problem, which may contain conflicts, this function uses the min-conflicts
    heuristic(see AIMA, pg. 221) to produce a conflict-free solution.

    Be sure to break 'ties' (in terms of minimial conflicts produced by a placement in a row) randomly.
    You should have a hard limit of 1000 steps, as your algorithm should be able to find a solution in far fewer (this
    is assuming you implemented initialize_greedy_n_queens.py correctly).

    Return the solution and the number of steps taken as a tuple. You will only be graded on the solution, but the
    number of steps is useful for your debugging and learning. If this algorithm and your initialization algorithm are
    implemented correctly, you should only take an average of 50 steps for values of N up to 1e6.

    As usual, do not change the import statements at the top of the file. You may import your initialize_greedy_n_queens
    function for testing on your machine, but it will be removed on the autograder (our test script will import both of
    your functions).

    On failure to find a solution after 1000 steps, return the tuple ([], -1).

    :param initialization: numpy array of shape (N,) where the i-th entry is the row of the queen in the ith column (may
                           contain conflicts)

    :return: solution - numpy array of shape (N,) containing a-conflict free assignment of queens (i-th entry represents
    the row of the i-th column, indexed from 0 to N-1)
             num_steps - number of steps (i.e. reassignment of 1 queen's position) required to find the solution.
    """

    N = len(initialization)
    solution = initialization.copy()
    num_steps = 0
    max_steps = 1000
    cols = np.arange(N)

    for _ in range(max_steps):
        if count_conflicts(solution, N) == 0:
            return solution, num_steps
        num_steps += 1

        # Identify queens with row conflicts
        unique_elements, counts = np.unique(solution, return_counts=True)
        duplicates = unique_elements[counts > 1]
        row_conflict_indices = np.where(np.isin(solution, duplicates))[0]

        # Identify queens with diagonal conflicts
        diag_matrix = np.abs(np.subtract.outer(cols, cols)) == np.abs(np.subtract.outer(solution, solution))
        np.fill_diagonal(diag_matrix, False)
        diag_conflict_indices = np.where(np.any(diag_matrix, axis=1))[0]

        # Randomly select a conflict to fix
        if diag_conflict_indices.size > 0 or row_conflict_indices.size > 0:
            if diag_conflict_indices.size > 0 and (np.random.randint(2) == 1 or row_conflict_indices.size == 0):
                conflict_index = np.random.choice(diag_conflict_indices)
                solution = handle_diag_conflict(solution, conflict_index)
            else:
                conflict_index = np.random.choice(row_conflict_indices)
                solution = handle_row_conflict(solution, conflict_index)
        else:
            return solution, num_steps

    return [], -1

def handle_diag_conflict(solution, idx):
    """
    For the queen in column idx (which has a diagonal conflict), evaluate every possible row (except its current one)
    in a vectorized way and choose one that minimizes the conflicts.
    """
    N = len(solution)
    original_row = solution[idx]
    # All rows except the queen's current row
    candidates = np.setdiff1d(np.arange(N), np.array([original_row]))

    # Prepare arrays of all other queens
    mask = np.ones(N, dtype=bool)
    mask[idx] = False
    other_solution = solution[mask]
    other_cols = np.arange(N)[mask]

    # For each candidate row, compute the conflicts
    candidates = candidates.reshape(-1, 1)  # shape (C, 1)
    row_conflicts = (other_solution == candidates)          # shape (C, N-1)
    diag_conflicts = (np.abs(candidates - other_solution) == np.abs(idx - other_cols))
    conflict_counts = np.sum(row_conflicts | diag_conflicts, axis=1)

    # Choose randomly among the candidates with minimum conflict count.
    min_conflict = np.min(conflict_counts)
    best_candidates = candidates[conflict_counts == min_conflict].flatten()
    if best_candidates.size > 0:
        solution[idx] = np.random.choice(best_candidates)
    else:
        solution[idx] = original_row
    return solution

def handle_row_conflict(solution, idx):
    """
    For the queen in column idx (which has a row conflict), evaluate in a vectorized way every possible row that is
    not already occupied by another queen (besides itself) and choose one that minimizes conflicts.
    """
    N = len(solution)
    original_row = solution[idx]

    used_rows = solution[np.arange(N) != idx]
    candidates = np.setdiff1d(np.arange(N), used_rows)
    if candidates.size == 0:
        return solution

    mask = np.ones(N, dtype=bool)
    mask[idx] = False
    other_solution = solution[mask]
    other_cols = np.arange(N)[mask]

    candidates = candidates.reshape(-1, 1)
    row_conflicts = (other_solution == candidates)
    diag_conflicts = (np.abs(candidates - other_solution) == np.abs(idx - other_cols))
    conflict_counts = np.sum(row_conflicts | diag_conflicts, axis=1)

    min_conflict = np.min(conflict_counts)
    best_candidates = candidates[conflict_counts == min_conflict].flatten()
    if best_candidates.size > 0:
        solution[idx] = np.random.choice(best_candidates)
    else:
        solution[idx] = original_row
    return solution

def count_conflicts(board, N):
    """
    Count the total number of conflicts on the board.
    Each queen's conflicts are calculated by counting other queens in the same row and on the same diagonal.
    """
    cols = np.arange(N)
    previous_queens = board[:, None]
    previous_cols = cols[:, None]
    
    # Row conflicts
    row_conflicts = np.sum(previous_queens == board, axis=0) - 1
    
    # Diagonal conflicts
    diag_conflicts = np.sum(
        np.abs(previous_queens - previous_queens.T) == np.abs(previous_cols - previous_cols.T),
        axis=0
    ) - 1
    
    total_conflicts = row_conflicts + diag_conflicts
    return np.sum(total_conflicts)

if __name__ == '__main__':
    # Test your code here!
    from initialize_greedy_n_queens import initialize_greedy_n_queens
    from support import plot_n_queens_solution

    N = 900
    assignment_initial = initialize_greedy_n_queens(N)
    plot_n_queens_solution(assignment_initial, "before.png")
    assignment_solved, n_steps = min_conflicts_n_queens(assignment_initial)
    # print("Total conflicts:", count_conflicts(assignment_solved, N))
    
    board = np.zeros((N, N))
    board[assignment_solved, np.arange(N)] = 1
    # print(board)
    
    plot_n_queens_solution(assignment_solved, "after.png")